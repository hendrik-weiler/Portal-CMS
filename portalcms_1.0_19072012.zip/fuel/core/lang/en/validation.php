<?php

return array(
	'required' => 'The field :label is required and must contain a value.',
	'min_length' => 'The field :label has to contain at least :param:1 characters',
	'max_length' => 'The field :label may not contain more than :param:1 characters',
);