<?php

return array(
'server/tooltip/:component/:path' => 'server/tooltip',
'server/layout/:file' => 'server/public',
'server/component/:component/:file' => 'server/component',
'server/:identifier' => 'server/index',
);