<?php

return array(
	'css' => array(
		'css->bootstrap' => DOCROOT . 'assets/css/bootstrap.css'
	),

	'js' => array(
		'js->bootstrap' => DOCROOT . 'assets/js/bootstrap.js'
	),
);