<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 13.09.2012 19:00:07 --> 8 - Undefined offset: 0 in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/permission.php on line 190
Error - 13.09.2012 19:00:07 --> 8 - Undefined index:  in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/permission.php on line 192
