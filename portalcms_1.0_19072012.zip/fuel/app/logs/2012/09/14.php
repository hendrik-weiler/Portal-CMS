<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 14.09.2012 16:53:14 --> 8 - Undefined offset: 0 in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/permission.php on line 190
Error - 14.09.2012 16:53:14 --> 8 - Undefined index:  in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/permission.php on line 192
Error - 14.09.2012 16:55:29 --> Error - Call to undefined function writeRowContent() in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/columns/sites.php on line 138
Error - 14.09.2012 17:08:04 --> 8 - Undefined variable: show_sub_field in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/columns/sites.php on line 110
Error - 14.09.2012 17:08:04 --> 8 - Undefined variable: parent in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/columns/sites.php on line 126
Error - 14.09.2012 17:08:04 --> 8 - Undefined variable: parent_array in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/columns/sites.php on line 126
Error - 14.09.2012 17:08:04 --> 4096 - Argument 3 passed to Fuel\Core\Form::select() must be an array, null given, called in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/columns/sites.php on line 126 and defined in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/form.php on line 451
Error - 14.09.2012 17:35:27 --> Error - Property "navigation_id" not found for model_db_navigation. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/packages/orm/classes/model.php on line 807
Error - 14.09.2012 17:43:59 --> Error - The requested view could not be found: admin/dashboard in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/view.php on line 389
Error - 14.09.2012 17:45:25 --> 8 - Undefined variable: permission in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 68
Error - 14.09.2012 17:45:25 --> 8 - Undefined variable: permission in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 72
Error - 14.09.2012 17:45:25 --> 8 - Undefined variable: permission in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 76
Error - 14.09.2012 17:45:25 --> 8 - Undefined variable: permission in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 80
Error - 14.09.2012 17:45:25 --> 8 - Undefined variable: permission in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 84
Error - 14.09.2012 17:46:12 --> 8 - Undefined offset: 0 in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 68
Error - 14.09.2012 17:46:12 --> 8 - Undefined offset: 2 in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 72
Error - 14.09.2012 17:46:12 --> 8 - Undefined offset: 4 in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 76
Error - 14.09.2012 17:46:12 --> 8 - Undefined offset: 3 in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 80
Error - 14.09.2012 17:46:12 --> 8 - Undefined offset: 5 in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 84
Error - 14.09.2012 17:46:45 --> 8 - Undefined variable: permission in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 68
Error - 14.09.2012 17:46:45 --> 8 - Undefined variable: permission in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 72
Error - 14.09.2012 17:46:45 --> 8 - Undefined variable: permission in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 76
Error - 14.09.2012 17:46:45 --> 8 - Undefined variable: permission in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 80
Error - 14.09.2012 17:46:45 --> 8 - Undefined variable: permission in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/index.php on line 84
Error - 14.09.2012 17:47:29 --> 8 - Undefined variable: permissions in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/dashboard/dashboard.php on line 35
Error - 14.09.2012 18:06:02 --> Error - Call to undefined function dump() in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/columns/dashboard.php on line 5
Error - 14.09.2012 18:54:45 --> 8 - Undefined index: navigation_sidebar in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/columns/dashboard.php on line 14
Error - 14.09.2012 18:54:45 --> 8 - Undefined index: navigation_sidebar in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/views/admin/columns/dashboard.php on line 15
Error - 14.09.2012 19:34:50 --> Error - Invalid method call.  Method get_col does not exist. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/packages/orm/classes/model.php on line 493
Error - 14.09.2012 19:34:58 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/db/accounts.php on line 36
Error - 14.09.2012 19:35:35 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/db/accounts.php on line 36
Error - 14.09.2012 19:35:36 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/db/accounts.php on line 36
Error - 14.09.2012 19:35:51 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/db/accounts.php on line 36
Error - 14.09.2012 19:35:52 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/db/accounts.php on line 36
Error - 14.09.2012 19:35:52 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/db/accounts.php on line 36
Error - 14.09.2012 19:35:52 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/db/accounts.php on line 36
Error - 14.09.2012 19:35:56 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/db/accounts.php on line 36
