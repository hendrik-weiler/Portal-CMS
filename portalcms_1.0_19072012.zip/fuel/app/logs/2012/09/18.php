<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 18.09.2012 17:00:02 --> 2 - file(/Users/hendrikweiler/Documents/sites/Portal-CMS/layouts/default/navigation.js) [<a href='function.file'>function.file</a>]: failed to open stream: No such file or directory in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/parser/js.php on line 33
Error - 18.09.2012 17:00:02 --> 2 - Invalid argument supplied for foreach() in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/parser/js.php on line 37
Error - 18.09.2012 17:00:02 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/parser/js.php on line 43
Error - 18.09.2012 17:04:20 --> 2 - file(/Users/hendrikweiler/Documents/sites/Portal-CMS/layouts/default/navigation.js) [<a href='function.file'>function.file</a>]: failed to open stream: No such file or directory in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/parser/js.php on line 33
Error - 18.09.2012 17:04:20 --> 2 - Invalid argument supplied for foreach() in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/parser/js.php on line 37
Error - 18.09.2012 17:04:20 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/parser/js.php on line 43
Error - 18.09.2012 17:05:51 --> 2 - file(/Users/hendrikweiler/Documents/sites/Portal-CMS/layouts/default/navigation.js) [<a href='function.file'>function.file</a>]: failed to open stream: No such file or directory in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/parser/js.php on line 33
Error - 18.09.2012 17:05:51 --> 2 - Invalid argument supplied for foreach() in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/parser/js.php on line 37
Error - 18.09.2012 17:05:51 --> 2 - implode() [<a href='function.implode'>function.implode</a>]: Invalid arguments passed in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/parser/js.php on line 43
Error - 18.09.2012 17:15:47 --> 2 - preg_match() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:15:47 --> 2 - preg_match() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:15:48 --> 2 - preg_match() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:15:49 --> 2 - preg_match() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:15:49 --> 2 - preg_match() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:15:49 --> 2 - preg_match() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:15:49 --> 2 - preg_match() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:15:51 --> 2 - preg_match() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:15:51 --> 2 - preg_match() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:16:20 --> 2 - preg_match() [<a href='function.preg-match'>function.preg-match</a>]: No ending delimiter '=' found in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:16:23 --> 2 - preg_match() [<a href='function.preg-match'>function.preg-match</a>]: No ending delimiter '=' found in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 59
Error - 18.09.2012 17:16:30 --> 2 - explode() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 61
Error - 18.09.2012 17:16:32 --> 2 - explode() expects parameter 2 to be string, array given in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/controller/supersearch/supersearch.php on line 61
Error - 18.09.2012 17:52:44 --> 8 - Undefined variable: user in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/auth.php on line 67
Error - 18.09.2012 17:52:44 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/auth.php on line 67
Error - 18.09.2012 17:52:44 --> 8 - Undefined variable: user in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/auth.php on line 67
Error - 18.09.2012 17:52:44 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/auth.php on line 67
Error - 18.09.2012 17:53:06 --> 8 - Undefined variable: user in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/auth.php on line 67
Error - 18.09.2012 17:53:06 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/auth.php on line 67
Error - 18.09.2012 17:53:06 --> 8 - Undefined variable: user in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/auth.php on line 67
Error - 18.09.2012 17:53:06 --> 8 - Trying to get property of non-object in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/app/classes/model/auth.php on line 67
Error - 18.09.2012 17:53:30 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:35 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:43 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:45 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:45 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:46 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:46 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:46 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:47 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:47 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:47 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:47 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:48 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:48 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:48 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:49 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
Error - 18.09.2012 17:53:49 --> Error - Invalid path, directory cannot be read. in /Users/hendrikweiler/Documents/sites/Portal-CMS/fuel/core/classes/file.php on line 201
