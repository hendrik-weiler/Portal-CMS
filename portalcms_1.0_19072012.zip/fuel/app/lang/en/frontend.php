<?php

return array(

	'news' => array(
    'more' => 'more',
    'dateformat' => 'Y-m-d H:i',
    'no_archive_data' => 'The archive is empty.',
    'archive_header' => 'News archive',
    'no_data' => 'No news written yet.'
   ),

   'contactform' => array(
      'send' => 'Submit',
      'success' => 'Completed!',
    ),

);