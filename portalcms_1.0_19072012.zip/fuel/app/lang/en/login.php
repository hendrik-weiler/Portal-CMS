<?php

return array(

	'username' => 'Username',
	'password' => 'Password',
	'button' => 'Login',

	'error' => 'Username or password is invalid.'

);