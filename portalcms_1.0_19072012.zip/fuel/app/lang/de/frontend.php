<?php

return array(

	'news' => array(
    'more' => 'mehr',
    'dateformat' => 'd.m.Y H:i',
    'no_archive_data' => 'Das Archiv ist leer.',
    'archive_header' => 'Nachrichten archiv',
    'no_data' => 'Es sind keine Nachrichten vorhanden.'
   ),

   'contactform' => array(
      'send' => 'Bestätigen',
      'success' => 'Gesendet!',
    ),

);