<?php

return array(

	'username' => 'Benutzername',
	'password' => 'Passwort',
	'button' => 'Einloggen',

	'error' => 'Benutzername oder Passwort ist falsch.'

);