<?php

interface plugin
{
	public function get_options();

	public function render();
}