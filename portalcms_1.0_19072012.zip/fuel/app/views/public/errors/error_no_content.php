<h1>Troubleshooting:</h1>

<h4>Why do i see this page?</h4>

You must create a content in your site first.