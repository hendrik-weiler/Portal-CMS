<h1>Troubleshooting:</h1>

<h4>Why do i see this page?</h4>

You must create a navigation with a site + content in it first. Then the first navigation will be displayed as default.