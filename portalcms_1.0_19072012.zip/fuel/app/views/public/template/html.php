<div class="html">
    <?php print $html; ?>
</div>