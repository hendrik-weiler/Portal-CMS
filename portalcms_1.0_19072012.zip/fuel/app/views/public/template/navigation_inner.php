<li>
<a target="<?php print $target; ?>" class="<?php print $active_class; ?>" href="<?php print $link; ?>"><?php print $label; ?></a>
{{INNER}}
</li>