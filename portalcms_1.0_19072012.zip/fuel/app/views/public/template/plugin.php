<div class="plugin">
	<h1><?php print $title; ?></h1>
	<?php print $content; ?>
</div>