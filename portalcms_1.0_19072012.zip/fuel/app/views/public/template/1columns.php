<article id="<?php print $group; ?>" class="textcontainer">
  <?php if(!empty($label)): ?>
	<h1>
		<?php print $label; ?>
	</h1>
  <?php endif; ?>
	<p>
		<?php print $text; ?>
	</p>
</article>