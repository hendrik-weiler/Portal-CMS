<li>
	<a <?php print $active ?>  href="<?php print $link; ?>"><?php print $label; ?></a>
</li>