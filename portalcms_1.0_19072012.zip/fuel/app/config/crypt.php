<?php
/**
 * Fuel is a fast, lightweight, community driven PHP5 framework.
 *
 * @package		Fuel
 * @version		1.0
 * @author		Fuel Development Team
 * @license		MIT License
 * @copyright	2011 Fuel Development Team
 * @link		http://fuelphp.com
 */

return array (
	'crypto_key' => 'Oe8F9cRGA-1ofXoftIJcMJdY',
	'crypto_iv' => 'EdkfmQgU88SUxOIWqYpPU4dg',
	'crypto_hmac' => 'G5IZy85-4J8wY609bAEz09sE',
);

