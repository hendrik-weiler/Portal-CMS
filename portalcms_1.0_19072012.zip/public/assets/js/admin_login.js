$(function() {
	var top = ($(window).height() / 2) - $('#container').height();

	$('#container').css({
		'margin-top' : top
	})
});